from .singly_linked_list import SinglyLinkedList
from .doubly_linked_list import DoublyLinkedList
